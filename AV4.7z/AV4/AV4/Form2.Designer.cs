﻿namespace AV4
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dgvVeiculos = new DataGridView();
            btnBaixa = new Button();
            ((System.ComponentModel.ISupportInitialize)dgvVeiculos).BeginInit();
            SuspendLayout();
            // 
            // dgvVeiculos
            // 
            dgvVeiculos.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvVeiculos.Location = new Point(46, 26);
            dgvVeiculos.Name = "dgvVeiculos";
            dgvVeiculos.RowHeadersWidth = 51;
            dgvVeiculos.Size = new Size(697, 188);
            dgvVeiculos.TabIndex = 0;
            // 
            // btnBaixa
            // 
            btnBaixa.Location = new Point(305, 242);
            btnBaixa.Name = "btnBaixa";
            btnBaixa.Size = new Size(173, 29);
            btnBaixa.TabIndex = 2;
            btnBaixa.Text = "Registrar Saída";
            btnBaixa.UseVisualStyleBackColor = true;
            btnBaixa.Click += btnCadastrar_Click;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnBaixa);
            Controls.Add(dgvVeiculos);
            Name = "Form2";
            Text = "Form2";
            Load += Form2_Load;
            ((System.ComponentModel.ISupportInitialize)dgvVeiculos).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView dgvVeiculos;
        private Button btnBaixa;
    }
}