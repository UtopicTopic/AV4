﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AV4
{
    public partial class Menu : Form
    {
        public Menu()
        {
            InitializeComponent();
            this.IsMdiContainer = true;
        }
        private void AbrirFormulario(Form form)
        {
            foreach (Form f in this.MdiChildren)
            {
                if (f.GetType() == form.GetType())
                {
                    f.Activate(); // Se já estiver aberto, só ativa
                    return;
                }
            }

            form.MdiParent = this;
            form.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            AbrirFormulario(new Form1());
        }

        private void button2_Click(object sender, EventArgs e)
        {
            AbrirFormulario(new Form2());
        }

        private void button3_Click(object sender, EventArgs e)
        {
            AbrirFormulario(new Form3());
        }
    }
}
