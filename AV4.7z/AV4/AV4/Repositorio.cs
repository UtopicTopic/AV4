﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Data;

namespace EstacionamentoApp
{
    public class Repositorio
    {
        private readonly Conexao conexao = new Conexao();

        public void InserirVaga(string numero)
        {
            using var conn = conexao.GetConnection();
            conn.Open();
            string sql = "INSERT INTO Vagas (Numero, Ocupada) VALUES (@num, 0)";
            MySqlCommand cmd = new MySqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@num", numero);
            cmd.ExecuteNonQuery();
        }

        public DataTable ListarVagas()
        {
            using var conn = conexao.GetConnection();
            conn.Open();
            string sql = "SELECT Id, Numero, IF(Ocupada=1,'Ocupada','Livre') AS Status FROM Vagas";
            MySqlDataAdapter da = new MySqlDataAdapter(sql, conn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            return dt;
        }

        public DataTable ListarVagasLivres()
        {
            using var conn = conexao.GetConnection();
            conn.Open();
            string sql = "SELECT Id, Numero FROM Vagas WHERE Ocupada=0";
            MySqlDataAdapter da = new MySqlDataAdapter(sql, conn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            return dt;
        }

        public void RegistrarEntrada(string placa, string modelo, string cor, int idVaga)
        {
            using var conn = conexao.GetConnection();
            conn.Open();
            using var trans = conn.BeginTransaction();

            try
            {
                string sqlVeiculo = "INSERT INTO Veiculos (Placa, Modelo, Cor, IdVaga) VALUES (@placa, @modelo, @cor, @vaga)";
                MySqlCommand cmd1 = new MySqlCommand(sqlVeiculo, conn, trans);
                cmd1.Parameters.AddWithValue("@placa", placa);
                cmd1.Parameters.AddWithValue("@modelo", modelo);
                cmd1.Parameters.AddWithValue("@cor", cor);
                cmd1.Parameters.AddWithValue("@vaga", idVaga);
                cmd1.ExecuteNonQuery();

                string sqlVaga = "UPDATE Vagas SET Ocupada=1 WHERE Id=@vaga";
                MySqlCommand cmd2 = new MySqlCommand(sqlVaga, conn, trans);
                cmd2.Parameters.AddWithValue("@vaga", idVaga);
                cmd2.ExecuteNonQuery();

                trans.Commit();
            }
            catch
            {
                trans.Rollback();
                throw;
            }
        }

        public DataTable ListarVeiculosEstacionados()
        {
            using var conn = conexao.GetConnection();
            conn.Open();
            string sql = @"SELECT v.Id, v.Placa, v.Modelo, v.Cor, g.Numero AS Vaga, v.Entrada
                           FROM Veiculos v
                           INNER JOIN Vagas g ON v.IdVaga=g.Id
                           WHERE v.Saida IS NULL";
            MySqlDataAdapter da = new MySqlDataAdapter(sql, conn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            return dt;
        }

        public void RegistrarSaida(int idVeiculo, int idVaga)
        {
            using var conn = conexao.GetConnection();
            conn.Open();
            using var trans = conn.BeginTransaction();

            try
            {
                string sqlSaida = "UPDATE Veiculos SET Saida=NOW() WHERE Id=@id";
                MySqlCommand cmd1 = new MySqlCommand(sqlSaida, conn, trans);
                cmd1.Parameters.AddWithValue("@id", idVeiculo);
                cmd1.ExecuteNonQuery();

                string sqlVaga = "UPDATE Vagas SET Ocupada=0 WHERE Id=@vaga";
                MySqlCommand cmd2 = new MySqlCommand(sqlVaga, conn, trans);
                cmd2.Parameters.AddWithValue("@vaga", idVaga);
                cmd2.ExecuteNonQuery();

                trans.Commit();
            }
            catch
            {
                trans.Rollback();
                throw;
            }
        }
    }
}
