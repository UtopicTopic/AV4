﻿namespace AV4
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dgvVagas = new DataGridView();
            btnCadastrar = new Button();
            txtNumero = new TextBox();
            Vaga = new Label();
            ((System.ComponentModel.ISupportInitialize)dgvVagas).BeginInit();
            SuspendLayout();
            // 
            // dgvVagas
            // 
            dgvVagas.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvVagas.Location = new Point(12, 12);
            dgvVagas.Name = "dgvVagas";
            dgvVagas.RowHeadersWidth = 51;
            dgvVagas.Size = new Size(506, 188);
            dgvVagas.TabIndex = 4;
            // 
            // btnCadastrar
            // 
            btnCadastrar.Location = new Point(244, 247);
            btnCadastrar.Name = "btnCadastrar";
            btnCadastrar.Size = new Size(94, 29);
            btnCadastrar.TabIndex = 5;
            btnCadastrar.Text = "Cadastrar";
            btnCadastrar.UseVisualStyleBackColor = true;
            btnCadastrar.Click += btnCadastrar_Click;
            // 
            // txtNumero
            // 
            txtNumero.Location = new Point(113, 249);
            txtNumero.Name = "txtNumero";
            txtNumero.Size = new Size(125, 27);
            txtNumero.TabIndex = 6;
            // 
            // Vaga
            // 
            Vaga.AutoSize = true;
            Vaga.Location = new Point(65, 253);
            Vaga.Name = "Vaga";
            Vaga.Size = new Size(42, 20);
            Vaga.TabIndex = 7;
            Vaga.Text = "Vaga";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(536, 409);
            Controls.Add(Vaga);
            Controls.Add(txtNumero);
            Controls.Add(btnCadastrar);
            Controls.Add(dgvVagas);
            Name = "Form1";
            Text = "x'";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)dgvVagas).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private DataGridView dgvVagas;
        private Button btnCadastrar;
        private TextBox txtNumero;
        private Label Vaga;
    }
}
