﻿namespace AV4
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dgvVeiculos = new DataGridView();
            btnEntrada = new Button();
            cmbVaga = new ComboBox();
            txtPlaca = new TextBox();
            txtCor = new TextBox();
            txtModelo = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            ((System.ComponentModel.ISupportInitialize)dgvVeiculos).BeginInit();
            SuspendLayout();
            // 
            // dgvVeiculos
            // 
            dgvVeiculos.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvVeiculos.Location = new Point(34, 17);
            dgvVeiculos.Name = "dgvVeiculos";
            dgvVeiculos.RowHeadersWidth = 51;
            dgvVeiculos.Size = new Size(718, 188);
            dgvVeiculos.TabIndex = 4;
            // 
            // btnEntrada
            // 
            btnEntrada.Location = new Point(52, 403);
            btnEntrada.Name = "btnEntrada";
            btnEntrada.Size = new Size(157, 49);
            btnEntrada.TabIndex = 9;
            btnEntrada.Text = "Cadastrar";
            btnEntrada.UseVisualStyleBackColor = true;
            btnEntrada.Click += btnEntrada_Click;
            // 
            // cmbVaga
            // 
            cmbVaga.FormattingEnabled = true;
            cmbVaga.Location = new Point(52, 358);
            cmbVaga.Name = "cmbVaga";
            cmbVaga.Size = new Size(157, 28);
            cmbVaga.TabIndex = 10;
            // 
            // txtPlaca
            // 
            txtPlaca.Location = new Point(84, 224);
            txtPlaca.Name = "txtPlaca";
            txtPlaca.Size = new Size(125, 27);
            txtPlaca.TabIndex = 11;
            // 
            // txtCor
            // 
            txtCor.Location = new Point(84, 316);
            txtCor.Name = "txtCor";
            txtCor.Size = new Size(125, 27);
            txtCor.TabIndex = 12;
            // 
            // txtModelo
            // 
            txtModelo.Location = new Point(84, 270);
            txtModelo.Name = "txtModelo";
            txtModelo.Size = new Size(125, 27);
            txtModelo.TabIndex = 13;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(34, 227);
            label1.Name = "label1";
            label1.Size = new Size(44, 20);
            label1.TabIndex = 14;
            label1.Text = "Placa";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(17, 273);
            label2.Name = "label2";
            label2.Size = new Size(61, 20);
            label2.TabIndex = 15;
            label2.Text = "Modelo";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(34, 319);
            label3.Name = "label3";
            label3.Size = new Size(32, 20);
            label3.TabIndex = 16;
            label3.Text = "Cor";
            // 
            // Form3
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 485);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtModelo);
            Controls.Add(txtCor);
            Controls.Add(txtPlaca);
            Controls.Add(cmbVaga);
            Controls.Add(btnEntrada);
            Controls.Add(dgvVeiculos);
            Name = "Form3";
            Text = "Form3";
            Load += Form3_Load;
            ((System.ComponentModel.ISupportInitialize)dgvVeiculos).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label label4;
        private DataGridView dgvVeiculos;
        private Button btnEntrada;
        private ComboBox cmbVaga;
        private TextBox txtPlaca;
        private TextBox txtCor;
        private TextBox txtModelo;
        private Label label1;
        private Label label2;
        private Label label3;
    }
}