﻿using EstacionamentoApp;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AV4
{
    public partial class Form2 : Form
    {
        private readonly Repositorio repo = new Repositorio();
        public Form2()
        {
            InitializeComponent();
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            if (dgvVeiculos.CurrentRow != null)
            {
                int idVeiculo = Convert.ToInt32(dgvVeiculos.CurrentRow.Cells["Id"].Value);
                int idVaga = repo.ListarVeiculosEstacionados()
                                .Select($"Id={idVeiculo}")[0].Field<int>("Id"); // pega id da vaga

                repo.RegistrarSaida(idVeiculo, idVaga);
                AtualizarGrid();
            }
        }

        private void AtualizarGrid()
        {
            dgvVeiculos.DataSource = repo.ListarVeiculosEstacionados();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            AtualizarGrid();
        }
    }
}
