using EstacionamentoApp;

namespace AV4
{
    public partial class Form1 : Form
    {
        private readonly Repositorio repo = new Repositorio();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            AtualizarGrid();
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(txtNumero.Text))
            {
                repo.InserirVaga(txtNumero.Text);
                txtNumero.Clear();
                AtualizarGrid();
            }
        }

        private void AtualizarGrid()
        {
            dgvVagas.DataSource = repo.ListarVagas();
        }
    }
}
