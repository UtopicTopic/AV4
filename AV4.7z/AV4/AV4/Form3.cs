﻿using EstacionamentoApp;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AV4
{
    public partial class Form3 : Form
    {
        private readonly Repositorio repo = new Repositorio();
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            AtualizarCombo();
            AtualizarGrid();
        }

        private void btnEntrada_Click(object sender, EventArgs e)
        {
            if (cmbVaga.SelectedValue != null)
            {
                repo.RegistrarEntrada(txtPlaca.Text, txtModelo.Text, txtCor.Text, (int)cmbVaga.SelectedValue);
                txtPlaca.Clear();
                txtModelo.Clear();
                txtCor.Clear();
                AtualizarCombo();
                AtualizarGrid();
            }
        }

        private void AtualizarCombo()
        {
            cmbVaga.DataSource = repo.ListarVagasLivres();
            cmbVaga.DisplayMember = "Numero";
            cmbVaga.ValueMember = "Id";
        }

        private void AtualizarGrid()
        {
            dgvVeiculos.DataSource = repo.ListarVeiculosEstacionados();
        }
    }
}
